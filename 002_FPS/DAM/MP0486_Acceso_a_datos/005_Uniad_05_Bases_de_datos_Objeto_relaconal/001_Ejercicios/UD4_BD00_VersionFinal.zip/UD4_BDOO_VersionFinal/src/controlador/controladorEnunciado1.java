/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import controlador.factory.controladorFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import modelo.dao.DepartamentoDAO;
import modelo.dao.EmpleadoDAO;
import modelo.vo.Departamento;
import modelo.vo.Empleado;
import vista.Enunciado1;

/**
 *
 * @author acceso a datos
 */
public class controladorEnunciado1 {

    public static DepartamentoDAO depDAO;
    public static EmpleadoDAO empDAO;
    public static Enunciado1 ventana = new Enunciado1();
    static DefaultComboBoxModel modelocombo = new DefaultComboBoxModel();

    public static void iniciar() {
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
        ventana.getCmbDepartamentos().setModel(modelocombo);
    }

    public static void iniciaBD() {
        controladorFactory.abrirBD();
        depDAO = controladorFactory.getDepartamentoDAO();
        empDAO = controladorFactory.getEmpleadoDAO();
    }

    public static void cerrarBD() {
        controladorFactory.cerrarBD();
    }

    public static void cargardatosenBD() {

        try {

            /**
             * Vamos a insertar 3 departamentos (10,20,40).El departamento 40 no
             * tendrá inicialmente empleados. Como no hay ningún tipo de
             * restricción, como el primary key, el las BDOO comprobamos
             * nosotros que el dato no existe. Si no hicieramos la comprobación
             * también lo haría, podrias comprobarlo sin hacer las
             * comprobaciones de existe. pero recuerda que NO NOS INTERESA.
             */
            /**
             * Iniciamos los departamentos con el hashset de los empleados
             * vacio*
             */
            //Para realizar búsquedas qbe (query by example) se le pasa el patrón 
            //del objeto a buscar. Indicamos diferentes patrones.
            //1.- Completo con datos; 2.-Completo con solo clave; 3.- Solo clave
            //Podría ponerse también algo como (null,null, "A Coruña"); 
            //Buscando todos los que sean de coruña
            Departamento d10 = depDAO.existeDepartamentoQBE(new Departamento(10, "Contabilidad", "A Coruña"));
            Departamento d20 = depDAO.existeDepartamentoQBE(new Departamento(20, null, null));
            Departamento d40 = depDAO.existeDepartamentoQBE(new Departamento(40));

            //Departamento d20 = new Departamento(20, "I+D", "Santiago");
            //Departamento d40 = new Departamento(40, "Produccion", "As pontes");
            /**
             * Para buscar el objeto utilizamos el QBE (Query by example). Como
             * funciona: Se le indica el objeto y lo busca. Se puede indicar
             * todos los campos como el caso del 20 o un constructor más simple
             * como en el 40. Los datos que no se buscan si son enteros se
             * sustituyen por 0, en otro caso null. Por eso aqui indicamos null
             * en todo para el ejemplo de buscar el 20.
             */
            if (d10 == null) {
                depDAO.insertar(new Departamento(10, "Contabilidad", "A Coruña"));
            }
            if (d20 == null) {
                depDAO.insertar(new Departamento(20, "I+D", "Santiago"));
            }
            if (d40 == null) {
                depDAO.insertar(new Departamento(40, "Produccion", "As pontes"));
            }

            //A continuación queremos insertar dos empleados en el departamento de contabilidad
            //Necesitamos el objeto del departamento de contabilidad que no lo tenemos.
            d10 = depDAO.existeDepartamentoQBE(new Departamento(10));

            //creamos los 2 objetos empleados
           // Empleado e1 = new Empleado(7396, "Garcia", "Vendedor", 7902, 800.0f, d10);
           // Empleado e2 = new Empleado(7566, "Nuñez", "Director", 7839, 1975.0f, d10);
            Empleado e1 = new Empleado(7396, "Garcia", 800.0f, d10);
            Empleado e2 = new Empleado(7566, "Nuñez",  1975.0f, d10);
            //Creamos una lista para añadir los empleados en el objeto del departamento.
            //Fijarse como en el modelo el departamento tiene la lista de empleados.
            List<Empleado> listaEmpleados = new ArrayList<>();

            listaEmpleados.addAll(d10.getListaEmpleados()); //Primero insertamos la lista que ya contiene.

            if (!listaEmpleados.contains(e1)) {
                listaEmpleados.add(e1);
            }

            if (!listaEmpleados.contains(e2)) {
                listaEmpleados.add(e2);
            }

            d10.setListaEmpleados(listaEmpleados);
            depDAO.modificar(d10);
            depDAO.cargarCombo(modelocombo);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Formato incorrecto en la entrada de datos");
        } catch (Exception ex1) {
            if (ex1.getMessage().contains("ejemplo.db4o")) {
                JOptionPane.showMessageDialog(null, "Cierra el ObjectManager");
            } else {
                JOptionPane.showMessageDialog(null, "Hubo un error");
            }
            Logger.getLogger(controladorEnunciado1.class.getName()).log(Level.SEVERE, null, ex1);
        }

    }

    public static void cargarCombo() {
        try {
            depDAO.cargarCombo(modelocombo);
        } catch (Exception ex) {
            Logger.getLogger(controladorEnunciado1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void cargardatos() {

        try {
            if (!ventana.getTxtNumEmp().getText().trim().isEmpty()) {
                Empleado e;
            
                    e = empDAO.existeEmpleadoNQ(Integer.valueOf(ventana.getTxtNumEmp().getText().trim()));
                    if (e != null) {
                        ventana.getTxtApellido().setText(e.getApellido());
                        ventana.getTxtSalario().setText(e.getSalario()+"");
                        ventana.getCmbDepartamentos().setSelectedItem(e.getDepartamento());
                    }else{ ventana.getTxtApellido().setText("");ventana.getTxtSalario().setText("");}
                    
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Formato Incorrecto en la entrada de datos");
        } catch (Exception e) {
            if (e.getMessage().contains("ejemplo.db40")) {
                JOptionPane.showMessageDialog(null, "Cierra el ObjectManager");
            } else {
                JOptionPane.showMessageDialog(null, "Hubo un error al cargar los datos");
            }
        }
    }

    public static void insertar() {
        if (ventana.getTxtNumEmp().getText().trim().isEmpty() || ventana.getTxtApellido().getText().trim().isEmpty()
                || ventana.getTxtSalario().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan datos");
            return;
        }
        if (ventana.getCmbDepartamentos().getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Elige Departamento");
            return;
        }

        try {
            //Se recomienda que mires los tres tipos de opciones.Bastará con que comentes/descomentes 
            //Empleado e = empDAO.existeEmpleadoQBE(Integer.valueOf(ventana.getTxtNumEmp().getText().trim()));
            //Empleado e = empDAO.existeEmpleadoSODA(Integer.valueOf(ventana.getTxtNumEmp().getText().trim()));
            Empleado e = empDAO.existeEmpleadoNQ(Integer.valueOf(ventana.getTxtNumEmp().getText().trim()));
            if (e == null) {
                //Si fuera el departamento bastaría con un store del objeto, pero en el departamento
                //hay que actualizar la lista del departamento. Observa como al insertar el empleado
                //La colección de su departamento se incrementa.

                //el objeto del combo no es el objeto departamento de la base de datos. Vamos a buscarlo
                //para pasarselo al insertar.
                Departamento dbuscado = depDAO.existeDepartamentoNQ((Departamento) ventana.getCmbDepartamentos().getSelectedItem());

                Empleado ecreado = new Empleado(Integer.valueOf(ventana.getTxtNumEmp().getText()),
                        ventana.getTxtApellido().getText(),
                        Double.valueOf(ventana.getTxtSalario().getText()),
                        dbuscado);

                //al actualizar la coleccion del departamento ya insertarmos el empleado
                depDAO.actualizarcoleccion(dbuscado, ecreado);

                JOptionPane.showMessageDialog(null, "Empleado Insertado");
            } else {
                JOptionPane.showMessageDialog(null, "El empleado ya existe");
                return;
            }
        } catch (NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Formato Incorrecto en la entrada de datos");
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().contains("ejemplo.db40")) {
                JOptionPane.showMessageDialog(null, "Cierra el ObjectManager");
            } else {
                JOptionPane.showMessageDialog(null, "Hubo un error");
            }
        }
    }

    public static void borrar() {
        if (ventana.getTxtNumEmp().getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan datos");
            return;
        }

        try {
            //Se recomienda que mires los tres tipos de opciones.Bastará con que comentes/descomentes 
            //Empleado e = empDAO.existeEmpleadoQBE(Integer.valueOf(ventana.getTxtNumEmp().getText().trim()));
            //Empleado e = empDAO.existeEmpleadoSODA(Integer.valueOf(ventana.getTxtNumEmp().getText().trim()));
            Empleado e = empDAO.existeEmpleadoNQ(Integer.valueOf(ventana.getTxtNumEmp().getText().trim()));

            if (e != null) {
                //No solo es un delete del objeto, hay que actualizar la coleccion del departamento.
                depDAO.actualizarcoleccion(e);
                empDAO.borrar(e);
                JOptionPane.showMessageDialog(null, "Empleado Eliminado");
                limpiardatos();
            } else {
                JOptionPane.showMessageDialog(null, "El empleado no existe");
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Formato Incorrecto en la entrada de datos");

        } catch (Exception e) {
            if (e.getMessage().contains("ejemplo.db40")) {
                JOptionPane.showMessageDialog(null, "Cierra el ObjectManager");
            } else {
                JOptionPane.showMessageDialog(null, "Hubo un error");
            }
        }
    }

    public static void listar() {

        limpiardatos2();

        try {
            //Forzamos a que si el campo de salario está vacio tenga valor para evitar errores.
            if (ventana.getTxtNumDep().getText().isEmpty()) {

                empDAO.TodosEmpleadosSODA(ventana.getTxtArea(),
                        ventana.getLblNombreDepartamento(), ventana.getLblNumeroEmpleados(),
                        ventana.getTxtSalconsulta().getText().trim());
            } else { //Como lo queremos para un departamento previamente lo buscamos por ejemplo con QBE
                Departamento d = depDAO.existeDepartamentoQBE(new Departamento(Integer.valueOf(ventana.getTxtNumDep().getText().trim())));
                if (d != null) {
                    empDAO.ListadosporDepartamentoNQ(d, ventana.getTxtArea(),
                            ventana.getLblNombreDepartamento(), ventana.getLblNumeroEmpleados(),
                            ventana.getTxtSalconsulta().getText().trim());
                } else {
                    JOptionPane.showMessageDialog(null, "Departamento no existente");
                    return;
                }
            }
        } catch (NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Formato Incorrecto en la entrada de datos");
        } catch (Exception e) {
            if (e.getMessage().contains("ejemplo.db40")) {
                JOptionPane.showMessageDialog(null, "Cierra el ObjectManager");
            } else {
                JOptionPane.showMessageDialog(null, "Hubo un error");
            }
        }
    }

    public static void modificar() {
        if (ventana.getTxtNumEmp().getText().trim().isEmpty() || ventana.getTxtApellido().getText().trim().isEmpty()
                || ventana.getTxtSalario().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan datos");
            return;
        }
        if (ventana.getCmbDepartamentos().getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Elige Departamento");
            return;
        }

        try {
            //Al modificar el empleado podríamos modificar el departamento en el que está. 
            //Es por ello que además de modificar el objeto,debemos actualizar las colecciones de los departamentos
            //que estuvieran afectadas. Si un empleado cambia del departamento A al B. La colección del departamento A perderia
            //un empleado y la del departamento B ganaría un empleado.

            Empleado e = empDAO.existeEmpleadoNQ(Integer.valueOf(ventana.getTxtNumEmp().getText().trim()));
            if (e != null) {
                //Si fuera el departamento bastaría con un store del objeto, pero en el departamento
                //hay que actualizar la lista del departamento. Observa como al modificar el empleado
                //La colección de su departamento se incrementa por un lado y se decrementa por otro.
                //1.- Eliminamos el empleado del departamento antiguo
                depDAO.actualizarcoleccion(e); //

                //el objeto del combo no es el objeto departamento de la base de datos. Vamos a buscarlo
                //para pasarselo al modificar colección.
                Departamento dbuscado = depDAO.existeDepartamentoNQ((Departamento) ventana.getCmbDepartamentos().getSelectedItem());
                empDAO.modificar(e, ventana.getTxtApellido().getText(), Double.valueOf(ventana.getTxtSalario().getText()), dbuscado);
//                Empleado emodificado = new Empleado(Integer.valueOf(ventana.getTxtNumEmp().getText()),
//                        );

                //al actualizar la coleccion del departamento ya modificamos el empleado
                depDAO.actualizarcoleccion(dbuscado, e);

                JOptionPane.showMessageDialog(null, "Empleado Modificado");
            } else {
                JOptionPane.showMessageDialog(null, "El empleado no existe");
                return;
            }
        } catch (NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Formato Incorrecto en la entrada de datos");
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().contains("ejemplo.db40")) {
                JOptionPane.showMessageDialog(null, "Cierra el ObjectManager");
            } else {
                JOptionPane.showMessageDialog(null, "Hubo un error");
            }
        }
    }

    private static void limpiardatos() {
        ventana.getTxtNumEmp().setText("");
        ventana.getTxtApellido().setText("");
        ventana.getTxtSalario().setText("");

    }

    private static void limpiardatos2() {
        ventana.getTxtArea().setText("");
        ventana.getLblNombreDepartamento().setText("");
        ventana.getLblNumeroEmpleados().setText("");
    }

}
