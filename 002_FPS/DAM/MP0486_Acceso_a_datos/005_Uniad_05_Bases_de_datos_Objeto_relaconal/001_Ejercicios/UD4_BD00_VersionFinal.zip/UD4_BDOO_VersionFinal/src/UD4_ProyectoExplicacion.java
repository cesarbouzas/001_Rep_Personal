
import controlador.controladorEnunciado1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license


/**
 *
 * @author Acceso a datos
 */
public class UD4_ProyectoExplicacion {

    public static void main(String[] args) {
        controladorEnunciado1.iniciar();
    }
}
