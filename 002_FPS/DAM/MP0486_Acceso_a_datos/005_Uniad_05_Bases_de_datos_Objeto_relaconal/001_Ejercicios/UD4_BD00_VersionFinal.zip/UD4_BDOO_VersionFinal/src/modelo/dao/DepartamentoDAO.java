/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import com.db4o.query.Query;
import controlador.factory.controladorFactory;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import modelo.vo.Departamento;
import modelo.vo.Empleado;

/**
 *
 * @author acceso a datos
 */
public class DepartamentoDAO {

    public void insertar(Departamento d) {
        controladorFactory.getBD().store(d);
    }

    public void modificar(Departamento d) {
        controladorFactory.getBD().store(d);
    }

    public void borrar(Departamento d) {
        controladorFactory.getBD().delete(d);
    }

    public Departamento existeDepartamentoQBE(Departamento d) throws Exception {

        ObjectSet result = controladorFactory.getBD().queryByExample(d);
        if (result.hasNext()) {
            return (Departamento) result.next();
        } else {
            return null;
        }
    }

    public Departamento existeDepartamentoNQ(Departamento dep) throws Exception {
        List<Departamento> result = controladorFactory.getBD().query(new Predicate<Departamento>() {
            public boolean match(Departamento d) {
                return d.getId() == (dep.getId());
            }
        });

        if (result.size() > 0) {
            return (Departamento) result.get(0);
        } else {
            return null;
        }

    }

    public static void cargarCombo(DefaultComboBoxModel modelocombo) throws Exception {
        Departamento d;

        modelocombo.removeAllElements();

        /**
         * Utilizaremos una consulta de tipo SODA para cargar los datos de los
         * departamentos.
         */
        Query query = controladorFactory.getBD().query();
        query.constrain(Departamento.class);
        ObjectSet result = query.execute();

        Iterator it = result.iterator();
        while (it.hasNext()) {
            d = (Departamento) it.next();
            modelocombo.addElement(d);
        }
    }

    
    public void actualizarcoleccion(Departamento d, Empleado e) {
       List <Empleado> listaEmpleados=new ArrayList<>();
            
       listaEmpleados.addAll(d.getListaEmpleados()); //Primero insertamos la lista que ya contiene.
            
       if (!listaEmpleados.contains(e)) 
           listaEmpleados.add(e);
            
       d.setListaEmpleados(listaEmpleados);
       this.modificar(d);          
    }
    public void actualizarcoleccion(Empleado e) {
       
        Departamento d=e.getDepartamento();
        //Hay que crear una estructura para que lo borre . No lo borra directamente.
        
        List <Empleado> listaEmpleados=new ArrayList<>();
        d.getListaEmpleados().remove(e);
        listaEmpleados.addAll(d.getListaEmpleados());
        d.setListaEmpleados(listaEmpleados);
 
        this.modificar(d);          
    }
}
