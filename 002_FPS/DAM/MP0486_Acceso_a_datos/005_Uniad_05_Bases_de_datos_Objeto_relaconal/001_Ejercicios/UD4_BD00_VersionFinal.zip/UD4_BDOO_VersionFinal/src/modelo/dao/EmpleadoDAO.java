/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import com.db4o.ObjectSet;
import com.db4o.query.Constraint;
import com.db4o.query.Predicate;
import com.db4o.query.Query;
import controlador.factory.controladorFactory;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import modelo.vo.Departamento;
import modelo.vo.Empleado;

/**
 *
 * @author Acceso a datos
 */
public class EmpleadoDAO {
    public void insertar(Empleado e) {
        controladorFactory.getBD().store(e);
    }
   public void modificar(Empleado e) { //este método podríamos utilizarlo si lo modificamos antes de pasarlo al método
        controladorFactory.getBD().store(e);
    }
    public void modificar(Empleado e, String apellido, Double salario, Departamento dep) {
        e.setApellido(apellido);
        e.setSalario(salario);
        e.setDepartamento(dep);
        controladorFactory.getBD().store(e);         
    }
    public void borrar(Empleado e) {
        controladorFactory.getBD().delete(e);
    }
    public Empleado existeEmpleadoQBE(int numemp) throws Exception {
        /**
         * Hay tres tipos de consulta: Query by Example (QBE), SODA Y Native
         * Query (NQ). En este caso utilizaremos Query by Example. En los query
         * by example se crea un objeto patrón de búsqueda. Los datos numéricos
         * van con 0, en este caso 0f por float y cualquier otro dato null.
         */
        Empleado e = new Empleado(numemp);
        ObjectSet result = controladorFactory.getBD().queryByExample(e);
        if (result.hasNext()) {
            return (Empleado) result.next();
        } else {
            return null;
        }
    }
    public Empleado existeEmpleadoSODA(int numemp) throws Exception {
        /**
         * Hay tres tipos de consulta: Query by Example (QBE), SODA Y Native
         * Query (NQ). En este caso utilizaremos SODA
         */
        Query query = controladorFactory.getBD().query();
        query.constrain(Empleado.class);
        query.descend("id").constrain(numemp);
        ObjectSet result = query.execute();
        if (result.hasNext()) {
            return (Empleado) result.next();
        } else {
            return null;
        }
    }
    public Empleado existeEmpleadoNQ(int numemp) throws Exception {
        /**
         * Hay tres tipos de consulta: Query by Example (QBE), SODA Y Native
         * Query (NQ). En este caso utilizaremos SODA. Este tipo de consultas
         * devuelven una lista Por eso si encuentra el empleado devuelve el
         * primer elemento de la lista.
         */

        List<Empleado> result = controladorFactory.getBD().query(new Predicate<Empleado>() {
            public boolean match(Empleado e) {
                return e.getId() == numemp;
            }
        });

        if (result.size() > 0) {
            return (Empleado) result.get(0);
        } else {
            return null;
        }
    }

   public void TodosEmpleadosSODA(JTextArea ta, JLabel lblNombreDepartamento, JLabel lblNumeroEmpleados, String salario) throws Exception{
        Empleado e=null;
        //Pasamos el string del salario a flotante. Si está vacio a 0 y sino a su valor correspondiente       
        float sal=(salario.isEmpty()?0f:Float.valueOf(salario));
        

        Query query=controladorFactory.getBD().query();
        query.constrain(Empleado.class); 
        Constraint condicion=query.descend("salario").constrain(sal).greater();
        query.descend("salario").constrain(sal).equal().or(condicion);
        ObjectSet result=query.execute();     

        lblNombreDepartamento.setText("TODOS");
        lblNumeroEmpleados.setText(result.size()+"");
        while (result.hasNext()) {
            e=(Empleado) result.next();
            ta.append(e.getApellido()+"------"+e.getSalario()+"------"+e.getDepartamento().getNombre()+"\n");
        }
    }

    public void ListadosporDepartamentoNQ(Departamento d,JTextArea ta, JLabel lblNombreDepartamento, JLabel lblNumeroEmpleados, String salario) throws Exception {
           
        float sal=(salario.isEmpty()?0f:Float.valueOf(salario));

         List<Empleado> result = controladorFactory.getBD().query(new Predicate<Empleado>() {
            public boolean match(Empleado e) {
                return e.getDepartamento().getId()==d.getId() && e.getSalario()>=sal;
            }
        });
        if (result.size()==0) ta.append("No tiene empleados");
        lblNombreDepartamento.setText(d.getNombre());
        lblNumeroEmpleados.setText(result.size()+"");
        for (Empleado e: result){
            ta.append(e.getApellido()+"------"+e.getSalario()+"\n");
        }    
    }
}
