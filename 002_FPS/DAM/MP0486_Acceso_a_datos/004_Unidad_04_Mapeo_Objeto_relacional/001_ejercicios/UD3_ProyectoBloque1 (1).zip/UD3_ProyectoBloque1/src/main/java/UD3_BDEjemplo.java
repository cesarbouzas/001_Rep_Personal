import controlador.*;

public class UD3_BDEjemplo {
    
    public static void main(String[] args) {
 
        //controladorEnunciado1.iniciar();
        controladorEnunciado2.iniciar();
        // controladorEnunciado3.iniciar();
        
    }      
}