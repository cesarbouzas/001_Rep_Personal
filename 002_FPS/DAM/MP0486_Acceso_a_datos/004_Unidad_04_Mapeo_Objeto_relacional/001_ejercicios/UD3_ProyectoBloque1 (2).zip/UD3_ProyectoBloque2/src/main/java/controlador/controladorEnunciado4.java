/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import controlador.factory.HibernateUtil;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.PersistenceException;
import javax.swing.JOptionPane;
import modelo.dao.DepartamentoDAO;
import modelo.dao.EmpleadoDAO;
import modelo.vo.Departamentos;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import vista.*;

/**
 *
 * @author acceso a datos
 */
public class controladorEnunciado4 {

    public static Session session;
    public static DepartamentoDAO depDAO;
    public static EmpleadoDAO empDAO;
    public static Enunciado4 ventana = new Enunciado4();

    public static void iniciar() {
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }

    public static void iniciaSession() {       
        session = HibernateUtil.getSessionFactory().openSession();
        depDAO = HibernateUtil.getDepartamentoDAO();
        empDAO = HibernateUtil.getEmpleadoDAO();
    }

    public static void cerrarSession() {
        session.close();
    }
        
    public static void cargardatos() {
        if (ventana.getTxtnumdep().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan datos");
            limpiardatos();
            return;
        }
        try {
            HibernateUtil.beginTx(session);
            //Cualquiera de los 2 métodos de búsqueda del departamento vale. Utiliza el que quieras. El primero 
            //Es por consulta, el segundo pasa la la clase y la clave.
           // Departamentos d = depDAO.buscarDepartamento(session, Short.valueOf(ventana.getTxtnumdep().getText()));
            Departamentos d = depDAO.getDepartamento(session, Short.valueOf(ventana.getTxtnumdep().getText()));
            if (d != null) {
                ventana.getTxtnombre().setText(d.getDnombre());
                ventana.getTxtlocalidad().setText(d.getLoc());
            } else {
                limpiardatos();
            }
            HibernateUtil.commitTx(session);
        } catch (NumberFormatException ex) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex1) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado4.class.getName()).log(Level.SEVERE, null, ex1);
        }
    }
    public static void insertarcomprobandopreviamente() {
        //En este caso insertamos, pero comprobamos previamente si el departamento existe. Si existe no lo inserta
        if (ventana.getTxtnumdep().getText().isEmpty() || ventana.getTxtnombre().getText().isEmpty() || ventana.getTxtlocalidad().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan Datos");
            return;
        }
        try {
            HibernateUtil.beginTx(session);
            Departamentos d = depDAO.getDepartamento(session, Short.valueOf(ventana.getTxtnumdep().getText()));
            if (d != null) {
                JOptionPane.showMessageDialog(null, "El departamento ya existe");
            } else {
                depDAO.insertar(session, Short.valueOf(ventana.getTxtnumdep().getText()),
                        ventana.getTxtnombre().getText(), ventana.getTxtlocalidad().getText());
                JOptionPane.showMessageDialog(null, "Registro insertado");
            }
            HibernateUtil.commitTx(session);

        } catch (NumberFormatException ex) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex1) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado4.class.getName()).log(Level.SEVERE, null, ex1);
        }
    }

    public static void insertarsincomprobarrecogiendoerror() {
        //En este caso directamente insertamos. Si hubiera duplicados, salta el error y hacemos rollback
        if (ventana.getTxtnumdep().getText().isEmpty() || ventana.getTxtnombre().getText().isEmpty() || ventana.getTxtlocalidad().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan Datos");
            return;
        }
        try {
            HibernateUtil.beginTx(session);
            
            depDAO.insertar(session,Short.valueOf(ventana.getTxtnumdep().getText()),
                                    ventana.getTxtnombre().getText(), 
                                   ventana.getTxtlocalidad().getText());
                                   
            JOptionPane.showMessageDialog(null, "Registro insertado");

            HibernateUtil.commitTx(session);

            //}catch (NonUniqueObjectException ex){ //Cualquiera de los 2 recoge el error.
        } catch (HibernateException ex) {
            JOptionPane.showMessageDialog(null, "El departamento ya existe");
            session.getTransaction().rollback();
        } catch (NumberFormatException ex1) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex2) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado4.class.getName()).log(Level.SEVERE, null, ex2);
        }
    }

    public static void borrarcomprobandopreviamente() {
        if (ventana.getTxtnumdep().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan Datos");
            return;
        }
        try {
            //Para poder borrar no puede tener empleados.
            HibernateUtil.beginTx(session);
            long numeroempleados = empDAO.cuentaempleadosdeldepartamento(session, Short.valueOf(ventana.getTxtnumdep().getText()));
            if (numeroempleados > 0) {
                JOptionPane.showMessageDialog(null, "El departamento tiene empleados. No se puede borrar");
                return;
            }
            Departamentos d = depDAO.getDepartamento(session, Short.valueOf(ventana.getTxtnumdep().getText()));
            if (d != null) {
                depDAO.borrar(session, d);
                limpiardatos();
            } else {
                JOptionPane.showMessageDialog(null, "Registro no existe");
                return;
            }
            HibernateUtil.commitTx(session);
            JOptionPane.showMessageDialog(null, "Registro borrado");
        } catch (NumberFormatException ex1) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex2) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado4.class.getName()).log(Level.SEVERE, null, ex2);
        }

    }

    public static void borrarsincomprobarrecogiendoerror() {
        if (ventana.getTxtnumdep().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan Datos");
            return;
        }
        try {
            //Para poder borrar no puede tener empleados.
            HibernateUtil.beginTx(session);
            Departamentos d = depDAO.getDepartamento(session, Short.valueOf(ventana.getTxtnumdep().getText()));
            if (d != null) {
                depDAO.borrar(session, d);
                limpiardatos();
            } else {
                JOptionPane.showMessageDialog(null, "Registro no existe");
                return;
            }
            HibernateUtil.commitTx(session);
            JOptionPane.showMessageDialog(null, "Registro borrado");

        } catch (PersistenceException ex) { // OJO EL ERROR NO LO DA AL BORRAR. LO DA AL CERRAR LA TRANSACCIÓN
            JOptionPane.showMessageDialog(null, "El departamento no se puede borrar");
            session.getTransaction().rollback();
        } catch (NumberFormatException ex1) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex2) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado4.class.getName()).log(Level.SEVERE, null, ex2);
        }

    }
    public static void borradoencascada() {
        if (ventana.getTxtnumdep().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan Datos");
            return;
        }
        try {
            //Borramos antes los empleados
            HibernateUtil.beginTx(session);
            Departamentos d = depDAO.getDepartamento(session, Short.valueOf(ventana.getTxtnumdep().getText()));
           
            if (d != null) {
                depDAO.borrar(session, d);  //Dentro borra los empleados si los hubiera. Recuerda que en el pojo le hemos quitado el borrado en cascada.
                limpiardatos();
            } else {
                JOptionPane.showMessageDialog(null, "Registro no existe");
            }
            session.getTransaction().commit();
            JOptionPane.showMessageDialog(null, "Departamento y empleados borrados");

        } catch (PersistenceException ex) { // OJO EL ERROR NO LO DA AL BORRAR. LO DA AL CERRAR LA TRANSACCIÓN
            JOptionPane.showMessageDialog(null, "El departamento no se puede borrar");
            session.getTransaction().rollback();
        } catch (NumberFormatException ex1) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex2) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado4.class.getName()).log(Level.SEVERE, null, ex2);
        }

    }

    public static void modificar() {
        if (ventana.getTxtnumdep().getText().isEmpty() || ventana.getTxtnombre().getText().isEmpty() || ventana.getTxtlocalidad().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan Datos");
            return;
        }
        try {
            HibernateUtil.beginTx(session);
            Departamentos d = depDAO.getDepartamento(session, Short.valueOf(ventana.getTxtnumdep().getText()));
           
            if (d != null) {
                depDAO.modificar(session,d,ventana.getTxtnombre().getText(), ventana.getTxtlocalidad().getText());
            } else {
                JOptionPane.showMessageDialog(null, "Registro no existe");
                return;
            }
            HibernateUtil.commitTx(session);
            JOptionPane.showMessageDialog(null, "Registro Modificado");
        
        } catch (NumberFormatException ex1) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex2) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado4.class.getName()).log(Level.SEVERE, null, ex2);
        }
    }
    
    private static void limpiardatos() {
        ventana.getTxtnombre().setText("");
        ventana.getTxtlocalidad().setText("");
    }
}
