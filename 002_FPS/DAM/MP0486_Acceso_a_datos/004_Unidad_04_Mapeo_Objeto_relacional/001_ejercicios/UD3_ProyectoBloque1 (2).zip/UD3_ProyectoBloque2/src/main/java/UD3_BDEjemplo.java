import controlador.*;

public class UD3_BDEjemplo {
    
    public static void main(String[] args) {
 
        //controladorEnunciado4.iniciar();
        //controladorEnunciado5.iniciar();
         controladorEnunciado6.iniciar();
        
    }      
}