/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;
import modelo.vo.Departamentos;
import modelo.vo.Empleados;
import org.hibernate.Session;
import org.hibernate.query.Query;

/**
 *
 * @author acceso a datos
 */
public class EmpleadoDAO {

    public long cuentaempleadosdeldepartamento(Session session, short numdep) throws Exception {
        Query q = (Query) session.createQuery("select count(*) from Empleados e where e.departamentos.deptNo=:numdep");

        q.setParameter("numdep", numdep);
        //OJO el count devuelve un long.

        return (long) q.uniqueResult();
    }

    public void cargartabla(Session session, Departamentos d, DefaultTableModel modelotabla) {
        Empleados e;
        modelotabla.setRowCount(0);

        Query q = session.createQuery("from Empleados e where e.departamentos.deptNo=:numdep");
        q.setParameter("numdep", d.getDeptNo());

        Iterator it = q.list().iterator();
        while (it.hasNext()) {
            modelotabla.setRowCount(modelotabla.getRowCount() + 1);
            e = (Empleados) it.next();
            modelotabla.setValueAt(e.getEmpNo(), modelotabla.getRowCount() - 1, 0);
            modelotabla.setValueAt(e.getApellido(), modelotabla.getRowCount() - 1, 1);
            modelotabla.setValueAt(e.getOficio(), modelotabla.getRowCount() - 1, 2);
            modelotabla.setValueAt(e.getDir(), modelotabla.getRowCount() - 1, 3);
            modelotabla.setValueAt(e.getFechaAlt(), modelotabla.getRowCount() - 1, 4);
            modelotabla.setValueAt(e.getSalario(), modelotabla.getRowCount() - 1, 5);
            modelotabla.setValueAt(e.getComision(), modelotabla.getRowCount() - 1, 6);
        }
    }

    public Empleados getEmpleado(Session session, short numemp) throws Exception {
        //importante. El get busca por la clave
        return session.get(Empleados.class, numemp);
    }

    public void insertar(Session session, short id, String apellido, String oficio, short dir, float salario, Departamentos d) {
        //Algunos campos como la fecha de alta o la comision ya lo hemos puesto en el constructor.
        //Hemos añadido un constructor en el modelo para el Enunciado 5
        Empleados e = new Empleados(id, apellido, oficio, dir, salario, d);
        session.save(e);
    }

    public boolean existeDir(Session session, short numdirector) {
        Empleados e = null;
        Query q = session.createQuery("from Empleados e where e.empNo=:numdirector");

        q.setParameter("numdirector", numdirector);
        e = (Empleados) q.uniqueResult();
        return e != null;    //Devuelve true si es un director y falso si no lo es.    

    }

    public void borrar(Session session, Empleados e) {
        session.delete(e);
    }

    public void modificar(Session session, Empleados e, String ape, String oficio, short director, float salario, Departamentos d) {
        e.setApellido(ape);
        e.setOficio(oficio);
        e.setDir(director);
        e.setSalario(salario);
        e.setDeptNo(d);
        session.update(e);
    }

    public void buscaempleadosporapellido(Session session, String apellido, JTextArea ta) {
        Empleados e;
        ta.setText("");
        //también se puede poner en una linea
        //Query q=session.createQuery(consulta).setParameter("ape", apellido.trim()+"%");

        String consulta = "from Empleados e where e.apellido like :ape";
        Query q = session.createQuery(consulta);
        q.setParameter("ape", apellido.trim() + "%");

        Iterator it = q.list().iterator();
        while (it.hasNext()) {
            e = (Empleados) it.next();
            ta.append(e.getEmpNo() + " " + e.getApellido() + " " + e.getOficio() + "\n");
        }
    }

    public void buscaempleadospordepartamento(Session session, int numdep, JTextArea ta, JLabel lblnombreDepartamento, JLabel lblNumeroEmpleados) {

        //Observaciones en principio la consulta 1 y la 2 son iguales si fuera con inner join.
        // Pero para sacar los departamentos que no tienen empleados nos interesa la segunda para hacer el left join
        //String consulta = "from Departamento d, Empleado e where d.id=e.departamento.id and d.id=:numdep";
        String consulta = "from Departamentos d left join d.empleadosList e where d.deptNo=:numdep ";

        Query q = session.createQuery(consulta).setParameter("numdep", numdep);
        //List<?> ResultList = (List<?>) q.list();
        Iterator it = q.list().iterator();

        //Para situar el numero de empleados
        if (it.hasNext()) {
            lblNumeroEmpleados.setText(String.valueOf(q.list().size()));
        } else {
            ta.setText("No existe el departamento");
        }
        while (it.hasNext()) {
            //Observa que esta consulta devuelve por cada registro un objeto departamento y un objeto empleado
            //Por eso recogemos cada elemento es un vector de objetos. El primer elemento es el departamento
            // y el segundo es el empleado.
            Object[] res = (Object[]) it.next();
            Departamentos dep = (Departamentos) res[0];
            lblnombreDepartamento.setText(dep.getDnombre());
            Empleados emp = (Empleados) res[1];
            if (emp == null) {
                /* en este caso el departamento no tiene empleados*/
                ta.setText("No tiene empleados");
                lblNumeroEmpleados.setText("0");
            } else {
                ta.append(emp.getEmpNo() + " " + emp.getApellido() + '\n');
            }
        }

    }

    public void salariospordepartamento(Session session, JTextArea ta, JLabel lblNumeroDepartamentos) {
        String consulta = "select d.dnombre,sum(e.salario) from Departamentos d left join d.empleadosList e group by d.id";
        Query q = session.createQuery(consulta);

        lblNumeroDepartamentos.setText("Departamentos-->" + String.valueOf(q.list().size()));

        Iterator it = q.list().iterator();
        while (it.hasNext()) {
            //Observa que esta consulta devuelve por cada registro un datos. Los podemos encontrar en cada elemento
            //del vector. No necesitamos castearlos a la clase
            Object[] res = (Object[]) it.next();
            //Nota a tener en cuenta: Si hacemos un sumatorio de un departamento que no existe el valor que devuelve sum es null,
            // por eso le indicamos que si lo que devuelve es null que realmente devuelva 0 y si no el valor.
            Double valor = (res[1] == null) ? 0.0 : (Double) res[1];
            ta.append(res[0] + "\t" + valor + "\n");
        }
    }

    public void empleadosdeferrolysantiago(Session session, JTextArea ta, JLabel lblNumeroEmpleados) {
        String consultalocalidades = "from Departamentos d where loc in ('Santiago','Ferrol')";
        Query q = session.createQuery(consultalocalidades);

        List<Object> localidades = new ArrayList<>();
        //La primera consulta la incorporamos a una lista. Que será el parámetro para la segunda consulta
        for (Object o : q.list()) {
            Departamentos dep = (Departamentos) o;
            localidades.add(dep.getDeptNo());
        }

        //**Cualquiera de las 2 consultas vale. La que se entienda mejor
        String consulta = "from Departamentos d inner join d.empleadosList where d.id in :listdep";
        //String consulta = "from Departamento d,Empleado e where d.id=e.departamento.id and d.id in :listdep";
        Query q2 = session.createQuery(consulta);
        q2.setParameterList("listdep", localidades);

        lblNumeroEmpleados.setText("Numero Empleados: " + q2.list().size() + "");
        for (Object e : q2.list()) {
            Object[] res = (Object[]) e;
            Empleados emp = (Empleados) res[1];
            ta.append(emp.getApellido() + "\t" + emp.getOficio() + "\n");
        }
    }

}
