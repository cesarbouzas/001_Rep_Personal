/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import controlador.factory.HibernateUtil;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.dao.DepartamentoDAO;
import modelo.dao.EmpleadoDAO;
import modelo.vo.Departamentos;
import modelo.vo.Empleados;
import org.hibernate.HibernateException;

import org.hibernate.Session;
import vista.*;

/**
 *
 * @author acceso a datos
 */
public class controladorEnunciado5 {

    public static Session session;
    public static DepartamentoDAO depDAO;
    public static EmpleadoDAO empDAO;
    public static Enunciado5 ventana = new Enunciado5();
    static DefaultComboBoxModel modelocombo = new DefaultComboBoxModel();
    static DefaultTableModel modelotabla = new DefaultTableModel();

    public static void iniciar() {
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
        ventana.getCmbDepartamento().setModel(modelocombo);
        modelotabla = (DefaultTableModel) ventana.getTblempleados().getModel();
    }

    public static void iniciaSession() {
        session = HibernateUtil.getSessionFactory().openSession();
        depDAO = HibernateUtil.getDepartamentoDAO();
        empDAO = HibernateUtil.getEmpleadoDAO();
    }

    public static void cerrarSession() {
        session.close();
    }

    public static void cargarcombo() {
        try {
            HibernateUtil.beginTx(session);         
            depDAO.cargacombo(session, modelocombo);
            HibernateUtil.commitTx(session);
        } catch (Exception ex) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado5.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void cargartabla() {
        try {
            HibernateUtil.beginTx(session);
            empDAO.cargartabla(session,(Departamentos) ventana.getCmbDepartamento().getSelectedItem(), modelotabla);
            HibernateUtil.commitTx(session);
        } catch (Exception ex) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado5.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void cargardatos() {
        if (ventana.getTxtnumero().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan datos");
            return;
        }
        try {
            HibernateUtil.beginTx(session);
            
            //Recuerda el get Funciona siempre que se busque la clave.
            Empleados e = empDAO.getEmpleado(session, Short.valueOf(ventana.getTxtnumero().getText()));
            //Empleado e = empDAO.buscarEmpleado(session, Integer.parseInt(ventana.getTxtnumero().getText()));
            if (e != null) {
                ventana.getTxtapellido().setText(e.getApellido());
                ventana.getTxtoficio().setText(e.getOficio());
                ventana.getTxtdirector().setText(e.getDir() + "");
                ventana.getTxtSalario().setText(e.getSalario() + "");
                modelocombo.setSelectedItem(depDAO.getDepartamento(session, e.getDeptNo().getDeptNo()));
            } else {
                limpiardatos();
            }
            HibernateUtil.commitTx(session);
        } catch (NumberFormatException ex) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado5.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void insertar() {
        if (ventana.getTxtnumero().getText().isEmpty() || ventana.getTxtapellido().getText().isEmpty() || ventana.getTxtoficio().getText().isEmpty()
                || ventana.getTxtdirector().getText().isEmpty() || ventana.getTxtSalario().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan datos");
            return;
        }
        try {
            HibernateUtil.beginTx(session);
            if (Double.parseDouble(ventana.getTxtSalario().getText()) <= 0.0) {
                JOptionPane.showMessageDialog(null, "Salario debe ser positivo");
                return;
            }
            if (!empDAO.existeDir(session, Short.valueOf(ventana.getTxtdirector().getText()))) {
                JOptionPane.showMessageDialog(null, "No existe el director");
                return;
            }
            empDAO.insertar(session, Short.valueOf(ventana.getTxtnumero().getText()),
                    ventana.getTxtapellido().getText(),
                    ventana.getTxtoficio().getText(),
                    Short.valueOf(ventana.getTxtdirector().getText()),
                    Float.valueOf(ventana.getTxtSalario().getText()),
                    (Departamentos) ventana.getCmbDepartamento().getSelectedItem());
            JOptionPane.showMessageDialog(null, "Registro Insertado");
          
            empDAO.cargartabla(session, (Departamentos) ventana.getCmbDepartamento().getSelectedItem(), modelotabla);
            HibernateUtil.commitTx(session);

        } catch (HibernateException ex) {
            JOptionPane.showMessageDialog(null, "El Empleado ya existe");
            session.getTransaction().rollback();
        } catch (NumberFormatException ex) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado5.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void borrar() {
        if (ventana.getTxtnumero().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan datos");
            return;
        }
        try {
            HibernateUtil.beginTx(session);
            Empleados e = empDAO.getEmpleado(session, Short.valueOf(ventana.getTxtnumero().getText()));
            if (e != null) {
                empDAO.borrar(session, e);
                limpiardatos();
            } else {
                JOptionPane.showMessageDialog(null, "Registro no existe");
                return;
            }
            
            empDAO.cargartabla(session, (Departamentos) ventana.getCmbDepartamento().getSelectedItem(), modelotabla);
            HibernateUtil.commitTx(session);

            //Observa: Si borramos un empleado que no vemos en la tabla......... y seleccionamos el combo
            // lo vemos........... es mejor recargar la tabla con la consulta.
        } catch (NumberFormatException ex) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado5.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void modificar() {
        if (ventana.getTxtnumero().getText().isEmpty() || ventana.getTxtapellido().getText().isEmpty() || ventana.getTxtoficio().getText().isEmpty()
                || ventana.getTxtdirector().getText().isEmpty() || ventana.getTxtSalario().getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Faltan datos");
            return;
        }

        try {
            HibernateUtil.beginTx(session);
            if (Double.parseDouble(ventana.getTxtSalario().getText()) <= 0.0) {
                JOptionPane.showMessageDialog(null, "Salario debe ser positivo");
                return;
            }
            if (!empDAO.existeDir(session, Short.valueOf(ventana.getTxtdirector().getText()))) {
                JOptionPane.showMessageDialog(null, "No existe el director");
                return;
            }

            Empleados e = empDAO.getEmpleado(session, Short.valueOf(ventana.getTxtnumero().getText()));
            if (e != null) {
                empDAO.modificar(session, e, ventana.getTxtapellido().getText(),
                        ventana.getTxtoficio().getText(),
                        Short.valueOf(ventana.getTxtdirector().getText()),
                        Float.valueOf(ventana.getTxtSalario().getText()),
                        (Departamentos) ventana.getCmbDepartamento().getSelectedItem());
            } else {
                JOptionPane.showMessageDialog(null, "Registro no existe");
                return;
            }
            
            empDAO.cargartabla(session, (Departamentos) ventana.getCmbDepartamento().getSelectedItem(), modelotabla);
            HibernateUtil.commitTx(session);

        } catch (NumberFormatException ex) {
            session.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Error en la entrada de datos");
        } catch (Exception ex) {
            session.getTransaction().rollback();
            Logger.getLogger(controladorEnunciado5.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void limpiardatos() {
        ventana.getTxtapellido().setText("");
        ventana.getTxtoficio().setText("");
        ventana.getTxtdirector().setText("");
        ventana.getTxtSalario().setText("");
    }

}
